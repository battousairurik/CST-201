import java.util.LinkedList;
import java.util.Queue;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Milestone7 extends Application{
	/*
	 * Utilize a graph and Breadth First Search in order to find paths through the maze
	 * Author: Michael Weaver
	 */
	//protected PopulateMaze maze = new PopulateMaze("src\\testMaze.csv");
	protected Queue<Vertex> pathQueue = new LinkedList<Vertex>();
	protected Graph nodesGraph = new Graph ("src\\testMaze.csv");
	
	public static void main(String[] args) {
		launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		Stage stage = new Stage();
		stage.setTitle("Milestone 7");
		GridPane pane = createGrid();
		Scene scene = new Scene(pane);
		stage.setScene(scene);
		stage.show();
	}
	private GridPane createGrid (){
		GridPane display = new GridPane();
		Text text;
		for (int x = 0; x < nodesGraph.getX(); x++){
			for (int y = 0; y < nodesGraph.getX(); y++){
				display.add(text = new Text(nodesGraph.getVertex(x, y).getVertexType()), y, x);
			}
		}
		return display;
	}
	private void findPaths (){
		Vertex currentVertex = nodesGraph.getStartVertex();
		do {
			currentVertex.setMovedIn(true);
			//Iterate through currentVertex neighbors and add them to the stack
			for (Neighbor next = currentVertex.getNeighbor(); next != null; next = next.getNextNeighbor()){
				//Check and make sure the neighboring vertex has not already been checked
				if (nodesGraph.getAdjacent(next.getVertexNum()).getMovedIn() == false)
					pathQueue.add(nodesGraph.getAdjacent(next.getVertexNum()));
			}
			//Mark current vertex as moved in
			currentVertex.setMovedIn(true);
			//Set current vertex to top of the queue
			currentVertex = pathQueue.poll();
		} while (pathQueue.isEmpty() == false && currentVertex.getIsEnd() == false);
	}
}
