import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JOptionPane;

import javafx.scene.Scene;
import javafx.stage.Stage;

public class Milestone4 extends MazeGUI{
	
	private Queue<MazeSquare> mazePath;
	private MazeSquare currentSquare;
	private Stage stage;
	private Scene scene;
	
	public Milestone4 (Stage stage, Scene scene){	
		mazePath = new LinkedList<MazeSquare>();
		this.stage = stage;
		this.scene = scene;
	}
	public void findPath (MazeSquare square){
		currentSquare = square;
		while (currentSquare.getIsEnd() == false && mazePath.isEmpty() == false){
			//Check possible moves, and if an exception is thrown ignore it and continue
			try {checkPossibleMoves(currentSquare, "up");} 
			catch (ArrayIndexOutOfBoundsException exception) {continue;}
			try {checkPossibleMoves(currentSquare, "right");} 
			catch (ArrayIndexOutOfBoundsException exception) {continue;}
			try {checkPossibleMoves(currentSquare, "left");} 
			catch (ArrayIndexOutOfBoundsException exception) {continue;}
			try {checkPossibleMoves(currentSquare, "down");} 
			catch (ArrayIndexOutOfBoundsException exception) {continue;}
			currentSquare.setMovedIn(true);
			//Alter display of visited squares as required
			currentSquare.setCustomDisplay("VIS\n.I.\nTED");
			//Change currentSquare to the front of the Queue
			currentSquare = mazePath.poll();
			//Create new display with updated visuals
			updateScene(stage, new Scene (createStackGrid()));
		}
		if (currentSquare.getIsEnd() == true){
			infoBox("Maze Successful", "Message");
		}
	}
	public static void infoBox(String infoMessage, String titleBar)
    {
        JOptionPane.showMessageDialog(null, infoMessage, "InfoBox: " + titleBar, JOptionPane.INFORMATION_MESSAGE);
    }
	//Method to check each direction and add to Queue if there is an available move
	private void checkPossibleMoves (MazeSquare square, String direction) {
		switch (direction){
		case "up": {
			if (maze.getMazeSquare(square.getRow() - 1, square.getColumn()).getIsMovable() == true
					&& maze.getMazeSquare(square.getRow() - 1, square.getColumn()).getMovedIn() == false)
				mazePath.add(maze.getMazeSquare(square.getRow() - 1, square.getColumn()));
			break;
		}
		case "down": {
			if (maze.getMazeSquare(square.getRow() + 1, square.getColumn()).getIsMovable() == true
					&& maze.getMazeSquare(square.getRow() + 1, square.getColumn()).getMovedIn() == false)
				mazePath.add(maze.getMazeSquare(square.getRow() + 1, square.getColumn()));
			break;
		}
		case "right": {
			if (maze.getMazeSquare(square.getRow(), square.getColumn() + 1).getIsMovable() == true
					&& maze.getMazeSquare(square.getRow(), square.getColumn() + 1).getMovedIn() == false)
				mazePath.add(maze.getMazeSquare(square.getRow(), square.getColumn() + 1));
			break;
		}
		case "left": {
			if (maze.getMazeSquare(square.getRow(), square.getColumn() - 1).getIsMovable() == true
					&& maze.getMazeSquare(square.getRow(), square.getColumn() - 1).getMovedIn() == false)
				mazePath.add(maze.getMazeSquare(square.getRow(), square.getColumn() - 1));
			break;
		}
		}
	}
}
