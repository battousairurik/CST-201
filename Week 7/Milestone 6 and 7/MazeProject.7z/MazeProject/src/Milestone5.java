import java.util.LinkedList;
import java.util.Queue;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

//Creating an entirely new GUI for this milestone to clean things up
//Also reminding myself to add comments because it's 10% of the grade
public class Milestone5 extends Application{
	//Manually insert default maze
	protected PopulateMaze maze = new PopulateMaze("src\\testMaze.csv");
	protected Queue<MazeSquare> heapQueue = new LinkedList<MazeSquare>();
	private MazeSquare currentSquare;
	private MazeSquare heapEnd;
	
	public static void main(String[] args) {
		launch(args);
    }
	@Override
	public void start(Stage arg0) throws Exception {
		Stage stage = new Stage();
		VBox vbox = new VBox();
		vbox.setAlignment(Pos.CENTER);
		vbox.setSpacing(15);
		vbox.setPadding(new Insets(10, 10, 10, 10));
		GridPane pane = createDisplay();
		Button heapBTN = new Button("Generate Path");
		heapBTN.setOnAction(e -> {
			setDisplay(currentSquare);
			calculateHeap(currentSquare);
			currentSquare = heapQueue.poll();
			createNewScreen(stage, vbox, heapBTN);
		});
		vbox.getChildren().addAll(pane, heapBTN);
		Scene scene = new Scene(vbox);
		stage.setScene(scene);
		stage.show();
	}
	//
	private GridPane createDisplay (){
		GridPane pane = new GridPane();
		Text display;
		//Read in the display for each MazeSquare in each location of the array into the GidPane
		for (int x = 0; x < maze.getXLength(); x++){
			for (int y = 0; y < maze.getYLength(); y++){
				pane.add(display = new Text(maze.getMazeSquare(x, y).getDisplay()),	y, x);
				//Set start square as current for future calculations
				if (maze.getMazeSquare(x, y).getIsStart() == true){
					currentSquare = maze.getMazeSquare(x, y);
				}
				//Set end square as goal for future comparisons
				if (maze.getMazeSquare(x, y).getIsEnd() == true){
					heapEnd = maze.getMazeSquare(x, y);
				}
			}
		}
		pane.setHgap(5);
		pane.setVgap(5);
		return pane;
	}
	//Method to check possible moves and then Enqueue the one with highest priority
	private void calculateHeap (MazeSquare square){
		int row = square.getRow();
		int column = square.getColumn();
		maze.getMazeSquare(row, column).setMovedIn(true);
		int priority = 0;
		//Ensure that array index does not go out of bounds
		if (row > 0){
			if (maze.getMazeSquare(row, column + 1).getMovedIn() == false){
				int temp = calculatePriority(maze.getMazeSquare(row - 1, column));
				if (temp > priority){
					priority = temp;
					row = square.getRow() - 1;
				}
			}
		}
		//Ensure that array index does not go out of bounds
		if (row < maze.getXLength()){
			if (maze.getMazeSquare(row, column + 1).getMovedIn() == false){
				int temp = calculatePriority(maze.getMazeSquare(row + 1, column));
				if (temp > priority){
					priority = temp;
					row = square.getRow() + 1;
				}
			}
		}
		//Ensure that array index does not go out of bounds
		if (column > 0){
			if (maze.getMazeSquare(row, column + 1).getMovedIn() == false){
				int temp = calculatePriority(maze.getMazeSquare(row, column - 1));
				if (temp > priority){
					priority = temp;
					column = square.getColumn() - 1;
				}
			}
		}
		//Ensure that array index does not go out of bounds
		if (column < maze.getYLength()){
			if (maze.getMazeSquare(row, column + 1).getMovedIn() == false){
				int temp = calculatePriority(maze.getMazeSquare(row, column + 1));
				if (temp > priority){
					priority = temp;
					column = square.getColumn() + 1;
				}
			}
		}
		heapQueue.add(maze.getMazeSquare(row, column));
	}
	//Method to calculate priority based on the Manhattan distance to end
	private int calculatePriority (MazeSquare square){
		int priority = (square.getRow() - heapEnd.getRow()) + (square.getColumn() - heapEnd.getColumn());
		return priority;
	}
	private void setDisplay(MazeSquare square){
		square.setCustomDisplay("...\n.!.\n...");
	}
	//Attempt to plug in existing nodes with an updated GridPane
	private void createNewScreen (Stage stage, VBox vbox, Button btn){
		vbox.getChildren().addAll(updateDisplay(), btn);
		Scene scene = new Scene(vbox);
		stage.setScene(scene);
		stage.show();
	}
	//Method to create a new gridpane with updated displays
	private GridPane updateDisplay(){
		GridPane pane = new GridPane();
		Text display;
		//Update gridpane display
		for (int x = 0; x < maze.getXLength(); x++){
			for (int y = 0; y < maze.getYLength(); y++){
				pane.add(display = new Text(maze.getMazeSquare(x, y).getDisplay()),	y, x);
			}
		}
		pane.setHgap(5);
		pane.setVgap(5);
		return pane;
	}
}
