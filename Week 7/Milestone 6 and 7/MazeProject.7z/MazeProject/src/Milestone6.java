import java.util.Stack;
import javafx.application.Application;
import javafx.stage.Stage;

public class Milestone6 extends Application{
	/*
	 * Utilize a graph and Depth First Search in order o find paths through the maze
	 * Author: Michael Weaver
	 */
	//protected PopulateMaze maze = new PopulateMaze("src\\testMaze.csv");
	protected Stack<MazeSquare> pathStack = new Stack<MazeSquare>();
	protected Graph nodesGraph = new Graph ("src\\testMaze.csv");
	
	public static void main(String[] args) {
		launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		
	}
	private void findPaths (){
		Vertex currentVertex = nodesGraph.getStartVertex();
		do {
			
		} while (pathStack.isEmpty() == false);
	}
}
