import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Graph {
	//Original list of vertices
	private Vertex [] adjLists;
	//Adjusted list of vertices to make the maze functionality easier
	private Vertex [][] adjLists2;
	//Store current file in use
	private File currentFile;
	//SAve start vertex for easy access
	private Vertex startVertex;
	//Default Constructor
	public Graph (String fileName){
		currentFile = new File (fileName);
		readFile();
	}
	//Default method to read in file
	private void readFile(){
		Scanner inputStream;
		try {
		inputStream = new Scanner(currentFile);
		//Read in first line to determine size of graph
		String data = inputStream.nextLine();
		String values [] = data.split(",");
		adjLists = new Vertex[Integer.parseInt(values[0]) * Integer.parseInt(values[1])];
		adjLists2 = new Vertex [Integer.parseInt(values[0])] [Integer.parseInt(values[1])];
		int indexNum = 0;
		String data2 = inputStream.nextLine();
		String values2 [] = data2.split(",");
		//Read in and set start vertex
		adjLists2[Integer.parseInt(values2[0])][Integer.parseInt(values2[1])] = 
				new Vertex ("" + indexNum, true, false, true);
		adjLists2[Integer.parseInt(values2[0])][Integer.parseInt(values2[1])].setIndex(indexNum++);
		setStartVertex(adjLists2[Integer.parseInt(values2[0])][Integer.parseInt(values2[1])]);
		String data3 = inputStream.nextLine();
		String values3 [] = data3.split(",");
		//Read in and set end vertex
		adjLists2[Integer.parseInt(values3[0])][Integer.parseInt(values3[1])] = 
				new Vertex ("" + indexNum, false, true, true);
		adjLists2[Integer.parseInt(values3[0])][Integer.parseInt(values3[1])].setIndex(indexNum++);
		//Read in and set all wall vertex
		while (inputStream.hasNext()){
			String data4 = inputStream.nextLine();
			String values4 [] = data4.split(",");
			adjLists2[Integer.parseInt(values4[0])][Integer.parseInt(values4[1])] = 
					new Vertex ("" + indexNum, false, false, false);
			adjLists2[Integer.parseInt(values4[0])][Integer.parseInt(values4[1])].setIndex(indexNum++);
		}
		//Create the rest of the vertices and allow them to be traversed
		for (int x = 0; x < adjLists2.length; x++){
			for (int y = 0; y < adjLists2[0].length; y++){
				if (adjLists2[x][y] != null)
					continue;
				else{
					adjLists2[x][y] = new Vertex ("" + indexNum, false, false, true);
					adjLists2[x][y].setIndex(indexNum++);
				}
					
			}
		}
		populateList();
		createNeighbors();
		inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//Need to check how many wall nodes there will be
	private int fileLengthCheck(){
		//Start at 0
		int x = 0;
		Scanner inputStream;
		try {
			inputStream = new Scanner (currentFile);
			while (inputStream.hasNext()){
				//Increment for every line encountered
				x++;
				inputStream.nextLine();
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Return result
		return x;
	}
	//Create list of vertices for reference in index order
	private void populateList(){
		for (int x = 0; x < adjLists2.length; x++){
			for (int y = 0; y < adjLists2[0].length; y++){
				//Add the 2D array of vertices to the list based on index
				adjLists[adjLists2[x][y].getIndex()] = adjLists2[x][y];
			}
		}
	}
	public void setStartVertex (Vertex start){
		startVertex = start;
	}
	public Vertex getStartVertex (){
		return startVertex;
	}
	public Vertex getAdjacent(int num){
		return adjLists[num];
	}
	private void createNeighbors(){
		
	}
}
class Vertex {
	private String name;
	private Neighbor adjList;
	//Allow the vertex to store it's own index to save time over scanning the entire vertex list
	private int listIndex;
	private MazeSquare square;
	private Boolean isStart;
	private Boolean isEnd;
	private Boolean isMovable;
	private Boolean movedIn;
	//Original Constructor
	Vertex(String name, Neighbor neighbors, MazeSquare square){
		this.name = "MazeSquare" + name;
		adjList = neighbors;
		this.square = square;
	}
	//Constructor after inspiration to remove MazeSquare from the program entirely
	Vertex(String name, Boolean start, Boolean finish, Boolean moveable){
		this.name = "Vertex" + name;
		isStart = start;
		isEnd = finish;
		isMovable = moveable;
	}
	public String getName(){
		return name;
	}
	public Neighbor getNeighbor(){
		return adjList;
	}
	public void setIndex(int index){
		listIndex = index;
	}
	public int getIndex(){
		return listIndex;
	}
	public MazeSquare getMazeSquare(){
		return square;
	}
	public void setIsStart (Boolean value){
		isStart = value;
	}
	public Boolean getIsStart (){
		return isStart;
	}
	public void setIsEnd (Boolean end){
		isEnd = end;
	}
	public Boolean getIsEnd(){
		return isEnd;
	}
	public void setIsMovable(Boolean value){
		isMovable = value;
	}
	public Boolean getIsMovable (){
		return isMovable;
	}
	public void setMovedIn(Boolean moved){
		movedIn = moved;
	}
	public Boolean getMovedIn (){
		return movedIn;
	}
}
//Class to store the list of neighbors of a vertex
class Neighbor {
	private int vertexNum;
	private Neighbor next;
	Neighbor (int num, Neighbor nbr){
		vertexNum = num;
		next = nbr;
	}
	public int getVertexNum(){
		return vertexNum;
	}
	public Neighbor getNextNeighbor(){
		return next;
	}
}
