import java.util.Stack;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MazeGUI extends Application implements EventHandler<KeyEvent>{

	protected PopulateMaze maze = new PopulateMaze("src\\testMaze.csv");
	private Image player = new Image("playerSprite.jpg");
	private ImageView playerIV = new ImageView(player);
	private ObservableList<String> movementTracking = FXCollections.observableArrayList();
	private Stack<MazeSquare> movementStack = new Stack<MazeSquare>();
	private GridPane gridPane;
	private int row, column;
	private Stage globalStage;
	private MazeSquare currentSquare;
	
	public static void main(String[] args) {
		launch(args);
    }
	@Override
	public void start(Stage arg0) throws Exception {
		movementTracking.add("Move using W/S/A/D.");
		Stage stage = new Stage();
		stage.setTitle("Maze Project");
		stage.setWidth(300);
		stage.setHeight(150);
		Button mazeBTN = new Button("Maze");
		mazeBTN.setOnAction(e -> createManualMaze());
		Button stackBTN = new Button("Stack Solve");
		stackBTN.setOnAction(e -> createStackMaze());
		Button queueBTN = new Button("Queue Solve");
		queueBTN.setOnAction(e -> createQueueMaze());
		HBox display = new HBox();
		display.getChildren().addAll(mazeBTN, stackBTN, queueBTN);
		display.setAlignment(Pos.CENTER);
		display.setSpacing(15);
		Scene scene = new Scene(display);
		stage.setScene(scene);
		stage.show();
	}
	protected void updateScene(Stage stage, Scene scene){
		stage.setScene(scene);
		scene.setOnKeyReleased(this);
		stage.show();
	}
	private void createManualMaze (){
		globalStage = createStage("Maze Project");
		Scene scene = new Scene(createHBox());
		scene.setOnKeyReleased(this);
		globalStage.setScene(scene);
		globalStage.show();
	}
	private Stage createStage (String title){
		Stage stage = new Stage();
		stage.setTitle(title);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		return stage;
	}
	private HBox createHBox(){
		HBox display = new HBox (8);
		display.getChildren().addAll(createGridPane(), createListDisplay());
		return display;
	}
	int single = 0;
	protected GridPane createGridPane () {
		gridPane = new GridPane();
		Text display;
		for (int x = 0; x < maze.getXLength(); x++){
			for (int y = 0; y < maze.getYLength(); y++){
				gridPane.add(display = new Text(maze.getMazeSquare(x, y).getDisplay()),
						y, x);
				if (single < 1){
					if (maze.getMazeSquare(x, y).getSquareType() == "start"){
					row = x;
					column = y;
				}
					single++;
				}
			}
		}
		gridPane.add(playerIV, column, row);
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		return gridPane;
	}
	private ListView<String> createListDisplay (){
		ListView<String> movementList = new ListView<String>(movementTracking);
		return movementList;
	}
	@Override
	public void handle(KeyEvent event) {
		switch(event.getCode()){
		case W: {
			if (testMovement("up") == true){
				setDisplay("up");
				addToList("up");
				if (row > 0) row--;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		case S: {
			if (testMovement("down") == true){
				setDisplay("down");
				addToList("down");
				if (row < maze.getXLength()) row++;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		case A: {
			if (testMovement("left") == true){
				setDisplay("left");
				addToList("left");
				if (column > 0) column--;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		case D: {
			if (testMovement("right") == true){
				setDisplay("right");
				addToList("right");
				if (column < maze.getYLength()) column++;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		default: break;
		}
	}
	private Boolean testMovement(String direction){
		Boolean movable = false;
		switch (direction){
		case "up":{
			if (maze.getMazeSquare(row - 1, column).getIsMovable() == true)
				movable = true;
			break;
		}
		case "down":{
			if (maze.getMazeSquare(row + 1, column).getIsMovable() == true)
				movable = true;
			break;
		}
		case "right":{
			if (maze.getMazeSquare(row, column + 1).getIsMovable() == true)
				movable = true;
			break;
		}
		case "left":{
			if (maze.getMazeSquare(row, column - 1).getIsMovable() == true)
				movable = true;
			break;
		}
		}
		return movable;
	}
	private void setDisplay(String direction){
		maze.getMazeSquare(row, column).setDisplayMovement(direction);
	}
	private void addToList(String direction){
		movementTracking.add("Player moving " + direction);
	}
	private void createStackMaze(){
		Stage stage = createStage("Stack Solve");
		
		GridPane display = new GridPane();
		
		Text textDisplay;
		for (int x = 0; x < maze.getXLength(); x++){
			for (int y = 0; y < maze.getYLength(); y++){
				display.add(textDisplay = new Text(maze.getMazeSquare(x, y).getDisplay()),
						y, x);
				if (maze.getMazeSquare(x, y).getSquareType() == "start"){
					currentSquare = maze.getMazeSquare(x, y);
				}
			}
		}
		display.setHgap(5);
		display.setVgap(5);
		Scene scene = new Scene(display);
		stage.setScene(scene);
		stage.show();
		while (currentSquare.getIsEnd() == false){
			int row = currentSquare.getRow();
			int column = currentSquare.getColumn();
			try {
				if (testStackMovement("up", row - 1, column) == true &&
						maze.getMazeSquare(row - 1, column).getMovedIn() == false){
					maze.getMazeSquare(row, column).setDisplayMovement("up");
					maze.getMazeSquare(row, column).setMovedIn(true);
					movementStack.push(currentSquare);
					currentSquare = maze.getMazeSquare(row - 1, column);
					updateScene(stage, scene = new Scene(createStackGrid()));
				}
				else if (testStackMovement("right", row, column + 1) == true &&
						maze.getMazeSquare(row, column + 1).getMovedIn() == false){
					maze.getMazeSquare(row, column).setDisplayMovement("right");
					maze.getMazeSquare(row, column).setMovedIn(true);
					movementStack.push(currentSquare);
					currentSquare = maze.getMazeSquare(row, column + 1);
					updateScene(stage, scene = new Scene(createStackGrid()));
				}
				else if (testStackMovement("down", row + 1, column) == true &&
						maze.getMazeSquare(row + 1, column).getMovedIn() == false){
					maze.getMazeSquare(row, column).setDisplayMovement("down");
					maze.getMazeSquare(row, column).setMovedIn(true);
					movementStack.push(currentSquare);
					currentSquare = maze.getMazeSquare(row + 1, column);
					updateScene(stage, scene = new Scene(createStackGrid()));
				}
				else if (testStackMovement("left", row, column - 1) == true &&
						maze.getMazeSquare(row, column - 1).getMovedIn() == false){
					maze.getMazeSquare(row, column).setDisplayMovement("left");
					maze.getMazeSquare(row, column).setMovedIn(true);
					movementStack.push(currentSquare);
					currentSquare = maze.getMazeSquare(row, column - 1);
					updateScene(stage, scene = new Scene(createStackGrid()));
				}
				else {
					currentSquare.setCustomDisplay("...\n.B.\n...");
					movementStack.pop();
					currentSquare = movementStack.peek();
				}
			} catch (ArrayIndexOutOfBoundsException exception) { break;}
			
		}
	}
	protected GridPane createStackGrid (){
		GridPane display = new GridPane();
		Text textDisplay;
		for (int x = 0; x < maze.getXLength(); x++){
			for (int y = 0; y < maze.getYLength(); y++){
				display.add(textDisplay = new Text(maze.getMazeSquare(x, y).getDisplay()),
						y, x);
			}
		}
		display.setVgap(5);
		display.setHgap(5);
		return display;
	}
	private Boolean testStackMovement(String direction, int row, int column){
		Boolean movable = false;
		switch (direction){
		case "up":{
			if (maze.getMazeSquare(row - 1, column).getIsMovable() == true)
				movable = true;
			break;
		}
		case "down":{
			if (maze.getMazeSquare(row + 1, column).getIsMovable() == true)
				movable = true;
			break;
		}
		case "right":{
			if (maze.getMazeSquare(row, column + 1).getIsMovable() == true)
				movable = true;
			break;
		}
		case "left":{
			if (maze.getMazeSquare(row, column - 1).getIsMovable() == true)
				movable = true;
			break;
		}
		}
		return movable;
	}
	private void createQueueMaze(){
		//create the maze display by utilizing existing methods
		Stage stage = createStage("Queue Maze");
		Scene scene = new Scene(createStackGrid());
		updateScene(stage, scene);
		Milestone4 queueSolver = new Milestone4(stage, scene);
		queueSolver.findPath(maze.getStartSquare());
		
	}
}
