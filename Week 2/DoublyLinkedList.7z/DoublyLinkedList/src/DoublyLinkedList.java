
public class DoublyLinkedList {

	protected Node start;
	protected Node end;
	public int size;
	
	public DoublyLinkedList (){
		start = null;
		end = null;
		size = 0;
	}
    
	public void insertStart (int x){
		Node temp = new Node(x, null, null);
		if (start == null){
			start = temp;
			end = start;
		}
		else {
			start.setLinkPrev(temp);
			temp.setLinkNext(start);
			start = temp;
		}
		size++;
	}
	public void insertAtPosition (int value, int pos){
		Node temp = new Node (value, null, null);
		if (pos == 1){
			insertStart(value);
			return;
		}
		Node temp2 = start;
		for (int i = 2; i <= size; i++){
			if (i == pos){
                Node tmp = temp2.getLinkNext();
                temp2.setLinkNext(temp);
                temp.setLinkPrev(temp2);
                temp.setLinkNext(tmp);
                tmp.setLinkPrev(temp);
			}
			temp2 = temp2.getLinkNext();
		}
		size++;
	}
    public void deleteAtPos(int pos){        
        if (pos == 1) 
        {
            if (size == 1)
            {
                start = null;
                end = null;
                size = 0;
                return; 
            }
            start = start.getLinkNext();
            start.setLinkPrev(null);
            size--; 
            return ;
        }
        if (pos == size)
        {
            end = end.getLinkPrev();
            end.setLinkNext(null);
            size-- ;
        }
        Node ptr = start.getLinkNext();
        for (int i = 2; i <= size; i++)
        {
            if (i == pos)
            {
                Node p = ptr.getLinkPrev();
                Node n = ptr.getLinkNext();
                p.setLinkNext(n);
                n.setLinkPrev(p);
                size-- ;
                return;
            }
            ptr = ptr.getLinkNext();
        }        
    }
    public Node copyLinkedList (Node original){
		Node head2 = new Node();
		Node tail2 = new Node();
		Node temp3 = head2;
		head2.setData(original.getData());
		head2.setLinkNext(tail2);
		head2.setLinkPrev(null);
		original = original.getLinkNext();
    	while (original.getLinkNext() != null){
    		//No idea if this works and i find it extremely confusing
    		Node temp = new Node();
    		temp.setData(original.getData());
    		temp.setLinkPrev(temp3);
    		temp.setLinkNext(tail2);
    		tail2 = temp;
    		temp3 = temp3.getLinkNext();
    		original = original.getLinkNext();
    	}
    	return head2;
    }
	public void reverseList (Node original){
		Node currentNode = original;
		Node previousNode = null;
		Node nextNode = null;
		while (currentNode != null){
			//Still can't quite follow the logic here so i'm not sure if it works
			nextNode = currentNode.getLinkNext();
			currentNode.setLinkNext(previousNode);
			currentNode.setLinkPrev(nextNode);
			previousNode = currentNode;
			currentNode = nextNode;
		}
		original = previousNode;
	}
	public void printData (Node head){
		while (head != null){
			System.out.print("->" + head.getData());
			head = head.getLinkNext();
		}
	}
    public static void main(String[] args) {
		

	}

}
