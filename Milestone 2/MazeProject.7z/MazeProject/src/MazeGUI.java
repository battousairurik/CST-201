import javafx.application.Application;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class MazeGUI extends Application{

	private PopulateMaze maze = new PopulateMaze();
	
	public static void main(String[] args) {
		launch(args);
		
    }
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public GridPane createGridPane () {
		GridPane gridPane = new GridPane();
		maze.getXLength();
		maze.getYLength();
		return gridPane;
	}
}
