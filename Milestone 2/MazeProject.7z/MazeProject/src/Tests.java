
public class Tests {

	public static void main(String[] args) {
		PopulateMaze maze1 = new PopulateMaze();
		String fileName = "src\\testMaze.csv";
		maze1.readFile(fileName);
		maze1.displayMaze();
		//maze1.readFileList(fileName);
		//maze1.printFromList();
	}

}
