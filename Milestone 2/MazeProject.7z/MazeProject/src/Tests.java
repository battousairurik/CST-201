
public class Tests {

	private static void test1 (){
		PopulateMaze maze1 = new PopulateMaze();
		String fileName = "src\\testMaze.csv";
		maze1.readFile(fileName);
		maze1.displayMaze();
	}
	private static void test2 (){
		Milestone2 maze = new Milestone2 ("src\\testMaze.csv");
		maze.readFile();
		maze.displayMaze();
	}
	public static void main(String[] args) {
		
		test2();
		
	}

}
