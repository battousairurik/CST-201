
public class Tests {

	public static void main(String[] args) {
		PopulateMaze maze1 = new PopulateMaze();
		maze1.readFile("src\\testMaze.csv");
		maze1.fillMaze();
		maze1.displayMaze();
	}

}
