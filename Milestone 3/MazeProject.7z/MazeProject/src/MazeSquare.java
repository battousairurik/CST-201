
public class MazeSquare {

	private Boolean isMovable;
	private Boolean isStart;
	private Boolean isEnd;
	private String display;
	private String squareType;
	private int column;
	private int row;
	private boolean movedIn;
	
	public MazeSquare () {}
	public MazeSquare (Boolean v1, Boolean v2, Boolean v3, String type) {
		setIsStart(v1);
		setIsEnd(v2);
		setIsMovable(v3);
		setSquareType(type);
	}
	
	public void setIsMovable (Boolean value){
		isMovable = value;
	}
	public Boolean getIsMovable (){
		return isMovable;
	}
	
	public void setIsStart (Boolean value){
		isStart = value;
	}
	public Boolean getIsStart (){
		return isStart;
	}
	
	public void setIsEnd (Boolean value){
		isEnd = value;
	}
	public Boolean getIsEnd (){
		return isEnd;
	}
	
	private void setDisplay (String type){
		if (type == "start"){
			display = "...\n.S.\n...";
		}
		else if (type == "finish"){
			display = "...\n.F.\n...";
		}
		else if (type == "wall"){
			display = "XXX\nXXX\nXXX";
		}
		else
			display = "...\n...\n...";
	}
	public void setDisplayMovement (String direction){
		if (direction == "up"){
			display = ".^.\n.^.\n.^.";
		}
		else if (direction == "down"){
			display = ".v.\n.v.\n.v.";
		}
		else if (direction == "right"){
			display = ".>.\n.>.\n.>.";
		}
		else if (direction == "left"){
			display = ".<.\n.<.\n.<.";
		}
	}
	public void setCustomDisplay (String display){
		this.display = display;
	}
	public String getDisplay (){
		return display;
	}
	
	public void setSquareType (String value){
		squareType = value;
		setDisplay(value);
	}
	public String getSquareType (){
		return squareType;
	}
	public void setRow (int row){
		this.row = row;
	}
	public int getRow (){
		return row;
	}
	public void setColumn(int column){
		this.column = column;
	}
	public int getColumn(){
		return column;
	}
	public void setMovedIn (Boolean value){
		movedIn = value;
	}
	public Boolean getMovedIn (){
		return movedIn;
	}
}
