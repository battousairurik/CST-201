import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PopulateMaze {

	private MazeSquare mazeSquares [][];
	private File currentFile;
	
	public PopulateMaze (){}
	public PopulateMaze (String fileName){
		readFile(fileName);
	}
	public void readFile (String fileName) {
		currentFile = new File(fileName);
		
		try {
			Scanner inputStream = new Scanner (currentFile);
			
			String data = inputStream.nextLine();
			String values [] = data.split(",");
			mazeSquares = new MazeSquare [Integer.parseInt(values[1])] [Integer.parseInt(values[0])];
			//input in the form of row then column
			fillMaze();
			
			String data2 = inputStream.nextLine();
			String values2 [] = data2.split(",");
			mazeSquares[Integer.parseInt(values2[1])][Integer.parseInt(values2[0])] = 
					createMazeSquare(true, false, true, "start");
			
			String data3 = inputStream.nextLine();
			String values3 [] = data3.split(",");
			mazeSquares[Integer.parseInt(values3[1])][Integer.parseInt(values3[0])] = 
					createMazeSquare(false, true, true, "finish");
			
			while (inputStream.hasNext()){
				String data4 = inputStream.nextLine();
				String values4 [] = data4.split(",");
					//for (int i = 0; i < values.length - 1; i += 2){
						mazeSquares[Integer.parseInt(values4[1])][Integer.parseInt(values4[0])] = 
					createMazeSquare(false, false, false, "wall");
					//}
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	private void fillMaze () {
		for (int x = 0; x < mazeSquares.length; x++){
			for (int y = 0; y < mazeSquares[x].length; y++){
				mazeSquares [x][y] = createMazeSquare(false, false, true, "space");
			}
		}
	}
	private MazeSquare createMazeSquare (Boolean v1, Boolean v2, Boolean v3, String type) {
		MazeSquare square = new MazeSquare(v1, v2, v3, type);
		return square;
	}
	public int getXLength (){
		return mazeSquares.length;
	}
	public int getYLength (){
		return mazeSquares[0].length;
	}
	public MazeSquare getMazeSquare (int row, int column){
		return mazeSquares[row][column];
	}
	public MazeSquare[][] getMazeSquares(){
		return mazeSquares;
	}
	public void displayMaze () {
		String [][] top = new String [mazeSquares.length] [mazeSquares[0].length];
		String [][] center = new String [mazeSquares.length] [mazeSquares[0].length];
		String [][] bottom = new String [mazeSquares.length] [mazeSquares[0].length];
		for (int x = 0; x < mazeSquares.length; x++){
			for (int y = 0; y < mazeSquares[0].length; y++){
				String values [] = mazeSquares[x][y].getDisplay().split("\n");
				top [x][y] = values[0];
				center [x][y] = values[1];
				bottom[x][y] = values[2];
			}
		}
		for (int x = 0; x < top.length; x++){
			for (int y = 0; y < top[0].length; y++){
				System.out.print(top[x][y]);
			}
			System.out.print("\n");
			for (int y = 0; y < top[0].length; y++){
				System.out.print(center[x][y]);
			}
			System.out.print("\n");
			for (int y = 0; y < top[0].length; y++){
				System.out.print(bottom[x][y]);
			}
			System.out.print("\n");
		}
	}	
}
