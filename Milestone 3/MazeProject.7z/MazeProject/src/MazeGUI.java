import java.util.Stack;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MazeGUI extends Application implements EventHandler<KeyEvent>{

	private PopulateMaze maze = new PopulateMaze("src\\testMaze.csv");
	private Image player = new Image("playerSprite.jpg");
	private ImageView playerIV = new ImageView(player);
	//private Stack<String> playerMovements = new Stack<String>();
	private ObservableList<String> movementTracking = FXCollections.observableArrayList();
	private GridPane gridPane;
	private int row, column;
	private Stage globalStage;
	
	public static void main(String[] args) {
		launch(args);
    }
	@Override
	public void start(Stage arg0) throws Exception {
		globalStage = createStage();
		Scene scene = new Scene(createHBox());
		scene.setOnKeyReleased(this);
		globalStage.setScene(scene);
		globalStage.show();
	}
	private void updateScene(Stage stage, Scene scene){
		stage.setScene(scene);
		scene.setOnKeyReleased(this);
		stage.show();
	}
	private Stage createStage (){
		Stage stage = new Stage();
		stage.setTitle("Maze Project");
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		return stage;
	}
	private HBox createHBox(){
		HBox display = new HBox (8);
		display.getChildren().addAll(createGridPane(), createListDisplay());
		return display;
	}
	int single = 0;
	private GridPane createGridPane () {
		gridPane = new GridPane();
		Text display;
		for (int x = 0; x < maze.getXLength(); x++){
			for (int y = 0; y < maze.getYLength(); y++){
				gridPane.add(display = new Text(maze.getMazeSquare(x, y).getDisplay()),
						y, x);
				if (single < 1){
					if (maze.getMazeSquare(x, y).getSquareType() == "start"){
					row = x;
					column = y;
				}
					single++;
				}
			}
		}
		gridPane.add(playerIV, column, row);
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		return gridPane;
	}
	private ListView<String> createListDisplay (){
		ListView<String> movementList = new ListView<String>(movementTracking);
		return movementList;
	}
	@Override
	public void handle(KeyEvent event) {
		switch(event.getCode()){
		case W: {
			if (testMovement("up") == true){
				//movePlayer("up");
				setDisplay("up");
				addToList("up");
				if (row > 0) row--;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		case S: {
			if (testMovement("down") == true){
				//movePlayer("down");
				setDisplay("down");
				addToList("down");
				if (row < maze.getXLength()) row++;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		case A: {
			if (testMovement("left") == true){
				//movePlayer("left");
				setDisplay("left");
				addToList("left");
				if (column > 0) column--;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		case D: {
			if (testMovement("right") == true){
				//movePlayer("right");
				setDisplay("right");
				addToList("right");
				if (column < maze.getYLength()) column++;
				updateScene(globalStage, new Scene(createHBox()));
			}
			break;
		}
		default: break;
		}
	}
	private Boolean testMovement(String direction){
		Boolean movable = false;
		switch (direction){
		case "up":{
			if (maze.getMazeSquare(row - 1, column).getIsMovable() == true)
				movable = true;
			break;
		}
		case "down":{
			if (maze.getMazeSquare(row + 1, column).getIsMovable() == true)
				movable = true;
			break;
		}
		case "right":{
			if (maze.getMazeSquare(row, column + 1).getIsMovable() == true)
				movable = true;
			break;
		}
		case "left":{
			if (maze.getMazeSquare(row, column - 1).getIsMovable() == true)
				movable = true;
			break;
		}
		}
		//GridPane.getRowIndex(playerIV);
		//GridPane.getColumnIndex(playerIV);
		return movable;
	}
	private void setDisplay(String direction){
		maze.getMazeSquare(row, column).setDisplayMovement(direction);
	}
	private void movePlayer(String direction) {
		TranslateTransition movement = new TranslateTransition();
		movement.setNode(playerIV);
		movement.setDuration(Duration.seconds(1));
		switch (direction){
		case "up": {
			movement.setByY(-53);
			movement.play();
			break;
		}
		case "down":{
			movement.setByY(53);
			movement.play();
			break;
		}
		case "right":{
			movement.setByX(27);
			movement.play();
			break;
		}
		case "left":{
			movement.setByX(-27);
			movement.play();
			break;
		}
		}
	}
	private void addToStack(String direction){
		//playerMovements.push("Player moving " + direction);
	}
	private void addToList(String direction){
		movementTracking.add("Player moving " + direction);
	}
}
