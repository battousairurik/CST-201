import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

public class Milestone2 {

	private File currentFile;
	private LinkedList <MazeSquare> squareList = new LinkedList<MazeSquare>();;
	private int mazeSize [] = new int [2];
	
	public Milestone2 (String file){
		currentFile = new File(file);
		readFile();
	}
	public Milestone2(){}
	
	public void readFile(){
		try {
			Scanner inputStream = new Scanner(currentFile);
			String data = inputStream.nextLine();
			String values [] = data.split(",");
			mazeSize[0] = Integer.parseInt(values[0]);
			mazeSize[1] = Integer.parseInt(values[1]);
			
			String data2 = inputStream.nextLine();
			String values2 [] = data2.split(",");
			squareList.add(createMazeSquare(true, false, true, "start", 
					Integer.parseInt(values2[1]), Integer.parseInt(values2[0])));
			
			String data3 = inputStream.nextLine();
			String values3 [] = data3.split(",");
			squareList.add(createMazeSquare(false, true, true, "finish",
					Integer.parseInt(values3[1]), Integer.parseInt(values3[0])));
			
			while (inputStream.hasNext()){
				String data4 = inputStream.nextLine();
				String values4 [] = data4.split(",");
				squareList.add(createMazeSquare(false, false, false, "wall",
						Integer.parseInt(values4[1]), Integer.parseInt(values4[0])));
				
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private MazeSquare createMazeSquare (Boolean v1, Boolean v2, Boolean v3, String type, int x, int y) {
		MazeSquare square = new MazeSquare(v1, v2, v3, type);
		square.setColumn(y);
		square.setRow(x);
		return square;
	}
	public void displayMaze (){
		String [][] top = new String [mazeSize[0]][mazeSize[1]];
		String [][] middle = new String [mazeSize[0]][mazeSize[1]];
		String [][] bottom = new String [mazeSize[0]][mazeSize[1]];
		
		for (int x = 0; x < mazeSize[0]; x++){
			for (int y = 0; y < mazeSize[1]; y++){
				String value = "...";
				top[x][y] = value;
				middle[x][y] = value;
				bottom[x][y] = value;
			}
		}
		for (MazeSquare square:squareList){
			String values []= square.getDisplay().split("\n");
			//top [square.getRow()][square.getColumn()] = values[0];
			top [square.getColumn()][square.getRow()] = values[0];
			//middle [square.getRow()][square.getColumn()] = values[1];
			middle [square.getColumn()][square.getRow()] = values[1];
			//bottom[square.getRow()][square.getColumn()] = values[2];
			bottom[square.getColumn()][square.getRow()] = values[2];
		}
		for (int x = 0; x < top.length; x++){
			for (int y = 0; y < top[0].length; y++){
				System.out.print(top[x][y]);
			}
			System.out.print("\n");
			for (int y = 0; y < top[0].length; y++){
				System.out.print(middle[x][y]);
			}
			System.out.print("\n");
			for (int y = 0; y < top[0].length; y++){
				System.out.print(bottom[x][y]);
			}
			System.out.print("\n");
		}
	}
}
